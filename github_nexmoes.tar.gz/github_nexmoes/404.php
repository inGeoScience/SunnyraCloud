<?php view::layout('layout')?>

<?php view::begin('content');?>
	<div class="mdui-typo-display-4" style="margin: 100px auto;text-align: center;">404 not found.</div>
<?php view::end('content');?>